======================================================
Apache Axis2 1.3 build (10-08-2007)
WAR distribution

http://ws.apache.org/axis2
------------------------------------------------------

This is Axis2 war distribution. Copy axis2.war file to a servlet container (eg: webapps folder in Apache Tomcat) & restart the server.

